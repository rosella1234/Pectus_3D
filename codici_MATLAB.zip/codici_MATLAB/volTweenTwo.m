%volTweenTwo.m
%Find volume between two surfaces.
%Surfaces are 5x40. Surf1=x,y,z. Surf2=x,y,z_upd.
%The x-coordinates of the surface points are somewhat irregular.  
%Therefore the cross section of each volume element between the surfaces
%has a trapezoidal cross section, when sliced perpendicular to the z-axis.
%The volume of each 6-sided volume element between the surfaces is computed.
%The volumes are summed to get the total volume between the surfaces.
%The volume of each six-sided element is approximated by the trapezoidal 
%area perpendicular to the z axis times the average difference in height 
%of the z coordinates of the top and bottom surfaces.  
%For average height difference, we use the simple average of the top four
%corner points versus the bottom four corner points.
%This approach is an approximation, because it gives equal weight to all 
%four corners.  I think the exactly correct approach is to give more weight
%to heights of corners on a long edge than to heights of corners on a short edge.
%W. Rose 20220625

% clear;

% load('x'); load('y'); load('z'); load('z_upd');
%Next lines are for testing
%z_upd=z;    %volume should=0 if this line not commented out
%z_upd=z+1;  %volume should = x-y area if this line not commented out
x=v_pectus(1,:);
y=v_pectus(2,:);
z=v_pectus(3,:);
z_upd=v_REG(3,:);

% figure; surf(x,y,z); %plot surface 1
% xlabel('X'); ylabel('Y'); zlabel('Z');
% view(0,90);  %view surface from directly overhead
% title('Surface viewed from above');
% %The overhead view shows that each volume element has a trapezoidal cross
%section, perpendicular to the z axis.

[r,c]=size(v_pectus);
m=r-1; n=c-1;
volel=zeros(1,c);
% for i=1:r
    for j=1:c-1
        %next line: area of trapezoidal cross section
        area=0.5*(x(j+1)-x(j)+x(j+1)-x(j))*(y(j)-y(j));
        %next line: compute average difference between top & bottom
        % height=0.25*abs(z_upd(i,j)+z_upd(i+1,j)+z_upd(i,j+1)+z_upd(i+1,j+1)...
        %                 -z(i,j)-z(i+1,j)-z(i,j+1)-z(i+1,j+1));
        % volel(i,j)=area*height;
        height=0.25*abs(z_upd(j)+z_upd(j)+z_upd(j+1)+z_upd(j+1)...
                        -z(j)-z(j)-z(j+1)-z(j+1));
        volel(j)=area*height;
    end
% end
vol=sum(sum(volel));  %add up all the volume elements
fprintf('Volume between surfaces~=%.2f.\n',vol);

        
