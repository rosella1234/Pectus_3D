function vol = Vertices2Volume(X, Y, Z)
% This function computes the volume of a 3D shape given its vertices X, Y,
% Z, povided X, Y, Z are such that can be plotted using surf function. 
%% Input
 % X = X-Coordinates
 % Y = Y-Coordinates
 % Z = Z-Coordinates
%% Output
 % vol = volume exclosed by the figure
%% Copyright
% Lateef Adewale Kareem 2023.
%% Solution
    % extract size and set vol to zero;
    [M, N] = size(X); vol = 0; 
    for m = 1:M-1
        for n = 1:N-1
            % convert subscripts of each quadrilateral to indices
            IND = sub2ind([M, N],[m, m, m+1, m+1],[n, n+1, n+1, n])';
            % split into indices of 2 triangles
            j = IND([1,2,4]); k = IND([2,3,4]);
            % compute the volume of the tetrahedral formed when each triangle 
            % is joined to the origin
            vol = vol + det([X(j), Y(j), Z(j)])/6 + det([X(k), Y(k), Z(k)])/6;
        end
    end
    vol = abs(vol);
end