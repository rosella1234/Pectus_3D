function [R,t]=Registration_3D(source_pts,destination_pts)
% Define the source and destination points
% source_pts = Points_sano;
% 
% destination_pts = Points_pectus;

% Calculate the centroids of the source and destination
    centroid_source = mean(source_pts, 1);
    centroid_destination = mean(destination_pts, 1);
    
    % Translate the source points to align centroids
    translated_source_pts = source_pts - centroid_source;
    
    % Compute the rotation matrix using Singular Value Decomposition (SVD)
    H = translated_source_pts' * (destination_pts - centroid_destination);
    [U, ~, V] = svd(H);
    R = V * U';
    
    % Check for reflection and correct it
    if det(R) < 0
        V(:,3) = V(:,3) * -1;
        R = V * U';
    end
    t = centroid_destination - (R * centroid_source')';
    
    % The transformation matrix combining rotation and translation
    T = eye(4);
    T(1:3, 1:3) = R;
    T(1:3, 4) = t;
end