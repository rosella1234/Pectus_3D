function M_world_rot = rotationVect3D(U, V, M_world)
% U is a unit vector representing Initial Vector;

% V is also a unit vector that represent the Destination Vector;

% M_world is a set of vectors with dimension 3 X N, where N is the number of
% vectors.
% M_world_tilt represents a set of vector for which the matrix RU has been
% applied
% return identity matrix if U and V are collinear
if norm(cross(U,V))==0
    % M_world_rot = eye(3)*M_world; % like applying the identity matrix
    M_world_rot = M_world;
else
    
    % verify that U and V are unit vectors, if not normalize them, normalize it...
    normU = norm(U);
    normV = norm(V);
    if normU==0 || normV==0
        error('One of the unit vector has a zeros norm');
    end
    
    if ~(normU==1)
        U = U/normU;
    end
    if ~(normV==1)
        V = V/normV;
    end
    
    % Anonymous function, compute the Skew-symmetric cross product matrix of v
    ssc = @(v) [0 -v(3) v(2); v(3) 0 -v(1); -v(2) v(1) 0];
    
    % Rotation Matrix RU that rotates unit vector "a" onto unit vector "b"
    RU = @(A,B) eye(3) + ssc(cross(A,B)) + ssc(cross(A,B))^2*(1-dot(A,B))/(norm(cross(A,B))^2);
    
    % Apply the Rotation Matrix to all vector of M_world
    matRot = RU(U,V);
    
    % Apply the matrix of Rotation on M_World
    M_world_rot = matRot*M_world;
    
end
end