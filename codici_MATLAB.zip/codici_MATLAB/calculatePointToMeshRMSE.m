function rmse = calculatePointToMeshRMSE(V1,F1, V2,F2 )
    % Load mesh data (replace these with actual mesh loading functions)
    % [V1, F1] = readMesh(mesh1); % Vertices and Faces of Mesh 1
    % [V2, F2] = readMesh(mesh2); % Vertices and Faces of Mesh 2

    % Calculate distances from each vertex in V1 to the nearest point in Mesh 2
    distances = arrayfun(@(idx) pointToMeshDistance(V1(idx, :), V2, F2), 1:size(V1, 1));
    
    % Calculate RMSE
    rmse = sqrt(mean(distances.^2));

    % Output RMSE
    fprintf('The RMSE between the two meshes is: %f\n', rmse);
end