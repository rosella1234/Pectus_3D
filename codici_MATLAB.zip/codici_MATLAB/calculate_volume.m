% Funzione per calcolare il volume tra mesh e piano 

function vol = calculate_volume(V, F, a, b, c, d)
    vol = 0;
    for i = 1:size(F, 1)
        % Estrapolo i vertici 3 vertici che formano ogni faccia
        v1 = V(:,F(i, 1));
        v2 = V(:,F(i, 2));
        v3 = V(:,F(i, 3));

        % Calcolo del centroide
        centroid = (v1 + v2 + v3) / 3;

        % Altezza dal centroide al corrispondente sul piano 
        height = abs(a*centroid(1) + b*centroid(2) + c*centroid(3) + d) / sqrt(a^2 + b^2 + c^2);

        % Areal del triangolo (cross prod)
        area = norm(cross(v2-v1, v3-v1)) / 2;

        % Somma volume in ogni iterazioni
        vol = vol + 1/3 * area * height;
    end
    vol = abs(vol);
end
