%codice per calcolare il volume tra le due 2 mesh pre e post operazione 
clear all
close all
clc

% load('FV_pectSEMPL.mat')
% load('FV_regSEMPL.mat')
% v_pectus=FV_pect.vertices'; %Mx3
% v_REG=FV_reg.vertices'; %Nx3 (mentre nell'altro script 3xn DECIDI QUALE TENERE)
% F3_pectus=FV_pect.faces';
% F3_sano=FV_reg.faces';

%% 
% 
% load('FV_pectSEMPL.mat')
% load('FV_regSEMPL.mat')
% v_pectus=FV_pectSEMPL.vertices'; %Mx3
% v_REG=FV_regSEMPL.vertices'; %Nx3 (mentre nell'altro script 3xn DECIDI QUALE TENERE)
% F3_pectus=FV_pectSEMPL.faces';
% F3_sano=FV_regSEMPL.faces';

% load('FileRagazza.mat')
% load('FileRagazzo.mat')
% load('FileManichino.mat')
% 
% % 
v_pectus=FV_pectpy.vertices'; %Mx3
v_REG=FV_REGpy.vertices'; %Nx3 (mentre nell'altro script 3xn)
F3_pectus=FV_pectpy.faces';
F3_sano=FV_REGpy.faces';

figure
patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on
patch('Vertices', v_REG', 'Faces', F3_sano', 'FaceColor',[1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
view([0 0])
xlabel('X');
ylabel('Y');
zlabel('Z');
sgtitle('V_pectus VS V_registered')
%%  PIANO CHE FITTA LA MESH E ROTAZIONE SU PIANO XY PER VISUALIZZARE 
%perchè se la radrizzo e la visualizzo cosi sono in grado di avere il vero minimo nella deformazione

figure
v_pectusFIT=v_pectus; %per non sovrascrivere
patch('Vertices',v_pectusFIT','Faces',F3_pectus','FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
% Trovo il piano che fitta la mesh
[n_1,~,p_1] = affine_fit(v_pectusFIT') ;  % dove n_1 è la normale al piano e p_1 è un punto appartenente al piano
% crea una griglia di punti X e Y che definiscono una superficie 
[X,Y]=meshgrid(linspace(min(v_pectusFIT(1,:)),max(v_pectusFIT(1,:)),100),linspace(min(v_pectusFIT(2,:)),max(v_pectusFIT(2,:)),100)); 
hold on    
Z = - (n_1(1)/n_1(3)*X + n_1(2)/n_1(3)*Y - dot(n_1, p_1)/n_1(3));
surf(X, Y, Z , 'FaceColor', 'red', 'FaceAlpha', 0.5); 
% Ruota i vertici della mesh in modo tale che il piano trovato sia parallelo al piano XY
R1 = rotationVect3D(n_1, [0 0 1], eye(3));  % Matrice di rotazione
v_pectusFIT = v_pectusFIT-p_1'; % centro la mesh sul piano XY
v_pectusFIT = R1*v_pectusFIT;   % ruoto i vertici
hold on
patch('Vertices', v_REG', 'Faces', F3_sano', 'FaceColor',[1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
facecolor = v_pectusFIT(3,:)';

xlabel('X');
ylabel('Y');
zlabel('Z');
%% RICERCA PUNTO DI MINIMO DELLA DEPRESSIONE

figure
patch('Vertices',v_pectusFIT','Faces',F3_pectus','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
axis('equal');

[X_min]=ginput(4);

indici_min = find(v_pectusFIT(1,:)>X_min(1)  & v_pectusFIT(1,:)<X_min(2));  %& v_pectusFIT(2,:)>X_min(3)  & v_pectusFIT(2,:)<X_min(4));

Z=v_pectusFIT(3,indici_min);
[~,ind_min]=min(Z);
indice_minimo_originale = indici_min(ind_min);
hold on
scatter3(v_pectusFIT(1,indice_minimo_originale),v_pectusFIT(2,indice_minimo_originale),v_pectusFIT(3,indice_minimo_originale),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k')

xlabel('X');
ylabel('Y');
zlabel('Z');
pause(1)
%% 
figure
patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
% hold on
% patch('Vertices', v_REG', 'Faces', F3_sano', 'FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on
scatter3(v_pectus(1,indice_minimo_originale),v_pectus(2,indice_minimo_originale),v_pectus(3,indice_minimo_originale),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k')
% [X,Y]=meshgrid(linspace(min(v_pectusFIT(1,:)),max(v_pectusFIT(1,:)),100),linspace(min(v_pectusFIT(2,:)),max(v_pectusFIT(2,:)),100)); 
% hold on     % mantiene la figura corrente aperta in modo che il piano possa essere sovrapposto alla mesh
% % plotta una superficie che rappresenta il piano trovato
% 
% Z = - (n_1(1)/n_1(3)*X + n_1(2)/n_1(3)*Y - dot(n_1, p_1)/n_1(3));
% surf(X, Y, Z+25 , 'FaceColor', 'red', 'FaceAlpha', 0.5); % Adjust Z by -300
% patch('Vertices', v_registered', 'Faces', F3_sano', 'FaceColor', [0 1 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
view([0 0])
xlabel('X');
ylabel('Y');
zlabel('Z');
%% PROVA PER TROVARE SLICE DEL MINIMO
% spessore=0.5;
% spess=0.2;
% indici_slice=find(v_pectus(2,:)>(v_pectus(2,indice_minimo_originale)-spessore) & v_pectus(2,:) < (v_pectus(2,indice_minimo_originale)+spessore));
% indici_vert=find(v_pectus(1,:)>(v_pectus(1,indice_minimo_originale)-spess) & v_pectus(1,:) < (v_pectus(1,indice_minimo_originale)+spess));
% 
% 
% indici_sliceREG=find(v_REG(2,:)>(v_pectus(2,indice_minimo_originale)-spessore) & v_REG(2,:) < (v_pectus(2,indice_minimo_originale)+spessore));
% indici_vertREG=find(v_REG(1,:)>(v_pectus(1,indice_minimo_originale)-spess) & v_REG(1,:) < (v_pectus(1,indice_minimo_originale)+spess));
% 
% figure;
% patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
% hold on;
% scatter3(v_pectus(1,indici_slice),v_pectus(2,indici_slice),v_pectus(3,indici_slice),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'g')
% hold on
% scatter3(v_pectus(1,indici_vert),v_pectus(2,indici_vert),v_pectus(3,indici_vert),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'y')
% % hold on
% % patch('Vertices', v_REG', 'Faces', F3_sano', 'FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
% hold on;
% scatter3(v_REG(1,indici_sliceREG),v_REG(2,indici_sliceREG),v_REG(3,indici_sliceREG),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'b')
% hold on
% scatter3(v_REG(1,indici_vertREG),v_REG(2,indici_vertREG),v_REG(3,indici_vertREG),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k')
% % 
% view([61 20]);
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% % P1=v_REGpaper(:,indici_sliceREG);
% % P2=v_pectus(:,indici_vert);
% % P = InterX3D(P1, P2);
% 
% [puntipianoX,puntipianoY]=ginput(4)
% %manca componente z!!!!
% 
% z = zeros(size(puntipianoX)); % Preallocate z-coordinates
% for i = 1:size(puntipianoX)
%     distances = sqrt((v_pectus(1,:) - puntipianoX(i)).^2 + (v_pectus(2,:) - puntipianoY(i)).^2);
%     [~, idx] = min(distances);
%     z(i) = v_pectus(3,idx);
% end
% 
% puntipiano=[puntipianoX,puntipianoY,z];
%% 
figure
facecolor = v_pectus(3,:)';    

patch('Vertices',v_pectus','Faces',F3_pectus','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
camlight('headlight'); % Aggiunge una luce nella posizione della camera
lighting gouraud; % Utilizza l'illuminazione Gouraud per un effetto morbido
material dull; % Rende il materiale meno riflettente per una visualizzazione più realistica

[puntipianoX,puntipianoY]=ginput()

z = zeros(size(puntipianoX)); % Preallocazione per componenti z
for i = 1:size(puntipianoX)
    distances = sqrt((v_pectus(1,:) - puntipianoX(i)).^2 + (v_pectus(2,:) - puntipianoY(i)).^2);
    [~, idx] = min(distances);
    z(i) = v_pectus(3,idx);
end

puntipiano=[puntipianoX,puntipianoY,z];

%% PIANO CHE PASSA PER 4 PUNTI (LE 2 COSTOLE X IL MOMENTO SELEZIONATE MANUALMENTE MA SAREBBERO IL MASSIMO IN QUELLA ZONA E I CAPEZZOLI)
% SUCCESSIVAMENTE SCELTI COME PUNTI CAPEZZOLI E OMBELICO QUINDI 3 

% Calcolo del piano usando SVD
media_punti = mean(puntipiano);
punti_cent = puntipiano - media_punti;  % Centralizza i punti

[U, S, V] = svd(punti_cent, 'econ');
normale = V(:,end);  % Il vettore normale al piano è l'ultima colonna di V

% Calcola d come il prodotto scalare della normale e uno dei punti mediati
d = normale' * media_punti';

fprintf('Equazione del piano: %.2fx + %.2fy + %.2fz = %.2f\n', normale(1), normale(2), normale(3), d);

% Plot della mesh con il piano 
figure;
patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on
plot3(puntipiano(:,1), puntipiano(:,2), puntipiano(:,3), 'bo');
hold on;
[x, y] = meshgrid(linspace(min(puntipiano(:,1)), max(puntipiano(:,1)), 10), linspace(min(puntipiano(:,2)), max(puntipiano(:,2)), 10));
z = (-normale(1)*x - normale(2)*y + d) / normale(3);
surf(x, y, z, 'FaceAlpha', 0.5);
xlabel('Asse X', 'FontSize', 14);
ylabel('Asse Y', 'FontSize', 14);
zlabel('Asse Z', 'FontSize', 14);
title('Piano attraverso i capezzoli e le costole');
grid on;
axis equal;
%% X valutare la distanza dal punto di minimo al piano (profondità della depressione toracica)
% Dati per il punto di minimo
x0 = v_pectus(1,indice_minimo_originale);  
y0 = v_pectus(2,indice_minimo_originale);  
z0 = v_pectus(3,indice_minimo_originale);  
% 

% Calcola la distanza dal piano
distanza = abs(normale(1)*x0 + normale(2)*y0 + normale(3)*z0 - d) / sqrt(normale(1)^2 + normale(2)^2 + normale(3)^2);
fprintf('La distanza dal punto al piano è: %.2f mm\n', distanza); %cm in teoria me lo aspetto un po piu grande perche piano piu in fuori boh

% Calcolo del punto di proiezione sul piano
proiezione = [x0, y0, z0] - (normale(1)*x0 + normale(2)*y0 + normale(3)*z0 - d) / (normale(1)^2 + normale(2)^2 + normale(3)^2) * normale';
hold on;
plot3(x0, y0, z0, 'go', 'MarkerSize', 10, 'LineWidth', 2);  % Punto di minimo
hold on
plot3([x0, proiezione(1)], [y0, proiezione(2)], [z0, proiezione(3)], 'k--', 'LineWidth', 2);  % Linea di distanza
hold on
plot3([x0, puntipiano(1,1)], [y0, puntipiano(1,2)], [z0, puntipiano(1,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
hold on
plot3([x0, puntipiano(2,1)], [y0, puntipiano(2,2)], [z0, puntipiano(2,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
hold on
plot3([x0, puntipiano(3,1)], [y0, puntipiano(3,2)], [z0, puntipiano(3,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
hold on
plot3([x0, puntipiano(4,1)], [y0, puntipiano(4,2)], [z0, puntipiano(4,3)], 'g--', 'LineWidth', 2);  % Linea di distanza

%
%% PROVA FUNZIONE CALCULATE_VOLUME 

V_pect = v_pectus;  
F_pect = F3_pectus;  

V_1=v_REG;
F_1=F3_sano;
% Coefficienti del piano 
a = normale(1); b = normale(2); c = normale(3); d = normale' * media_punti';  


volume = calculate_volume(V_pect, F_pect, a, b, c, d);
volume_1=calculate_volume(V_1, F_1, a, b, c, d);
disp(['Volume pectus-plane: ', num2str(volume), 'mm3']);
disp(['Volume post-plane: ', num2str(volume_1), 'mm3']);
diff=abs((volume-volume_1))/1000;
disp(['differenza=',num2str(diff), 'mL'])
pectus_volume = calculate_pectus_volume(V_pect, F_pect', a,b,c,d);
sano_volume=calculate_pectus_volume(V_1, F_1', a, b, c, d);

disp(['Il volume del pectus calcolato è ', num2str(pectus_volume), ' mL']);
disp(['Il volume del post calcolato è ', num2str(sano_volume), ' mL']);

%% 
figure;
patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on
plot3(puntipiano(:,1), puntipiano(:,2), puntipiano(:,3), 'bo');
hold on;
patch('Vertices', v_REG', 'Faces', F3_sano', 'FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on;
% Parametri per il piano di disegno
[x, y] = meshgrid(linspace(min(puntipiano(:,1)), max(puntipiano(:,1)), 10), linspace(min(puntipiano(:,2)), max(puntipiano(:,2)), 10));
z = (-normale(1)*x - normale(2)*y + d) / normale(3);

% Disegna il piano
surf(x, y, z, 'FaceAlpha', 0.5);
xlabel('x');
ylabel('y');
zlabel('z');
title('Piano attraverso i capezzoli e le costole');
grid on;
axis equal;

%% SE INVECE TAGLIASSI SOLO L'AREA DELLA MESH DEFINITA DAI PUNTIPIANO 
% % il minimo della depressione
% x_toVolmin = min(puntipiano(:,1));
% x_toVolmax = max(puntipiano(:,1));
% y_toVolmin = min(puntipiano(:,2));
% y_toVolmax = max(puntipiano(:,2));
% 
% % Filtra mesh per mantenere solo quelli all'interno del rettangolo
% mask = v_pectus(1,:) >= x_toVolmin & v_pectus(1,:)  <= x_toVolmax   & v_pectus(2,:) >= y_toVolmin & v_pectus(2,:)  <= y_toVolmax;
% 
% idx=find(mask);
% F=F3_pectus';
% 
% % Filtra anche le facce per mantenere solo quelle che usano i vertici filtrati
% % Assumo che F sia definita correttamente per v_pectus
% maskF = all(ismember(F, idx), 2);
% F_filtered = F(maskF, :);
% 
% % Mappa gli indici filtrati ai nuovi indici
% [~, new_indices] = ismember(F_filtered, idx);
% F_filtered = reshape(new_indices, size(F_filtered));
% 
% % Visualizza la mesh filtrata
% figure;
% trisurf(F_filtered, v_pectus(1,idx), v_pectus(2,idx), v_pectus(3,idx), 'EdgeColor', 'none');
% hold on
% 
% % Parametri per il piano di disegno
% [x, y] = meshgrid(linspace(min(puntipiano(:,1)), max(puntipiano(:,1)), 10), linspace(min(puntipiano(:,2)), max(puntipiano(:,2)), 10));
% z = (-normale(1)*x - normale(2)*y + d) / normale(3);
% 
% % Disegna il piano
% surf(x, y, z, 'FaceColor', 'red', 'FaceAlpha', 0.5);
% hold on
% plot3(puntipiano(:,1), puntipiano(:,2), puntipiano(:,3), 'bo');
% hold on;
% plot3(x0, y0, z0, 'go', 'MarkerSize', 10, 'LineWidth', 2);  % Punto di minimo
% hold on
% plot3([x0, proiezione(1)], [y0, proiezione(2)], [z0, proiezione(3)], 'k--', 'LineWidth', 2);  % Linea di distanza
% hold on
% plot3([x0, puntipiano(1,1)], [y0, puntipiano(1,2)], [z0, puntipiano(1,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
% hold on
% plot3([x0, puntipiano(2,1)], [y0, puntipiano(2,2)], [z0, puntipiano(2,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
% hold on
% plot3([x0, puntipiano(3,1)], [y0, puntipiano(3,2)], [z0, puntipiano(3,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
% hold on
% plot3([x0, puntipiano(4,1)], [y0, puntipiano(4,2)], [z0, puntipiano(4,3)], 'g--', 'LineWidth', 2);  % Linea di distanza
% 
% volume = calculate_volume(v_pectus(:,idx), F_filtered,  a, b, c, d);
% 
% disp(['Il volume calcolato è: ', num2str(volume_1), ' cubic units']);
% 
%% CALCOLA LA STEEPNESS 

% Coordinate dei punti sul piano e del punto esterno
P = puntipiano;  % Matrice dei punti sul piano
Q = [x0 y0 z0];  % Coordinate del punto esterno

% Inizializza una matrice per i vettori e gli angoli
V = zeros(size(P));
angles = zeros(size(P, 1), 1);

% Calcola i vettori e gli angoli
for i = 1:size(P, 1)
    V(i, :) = Q - P(i, :);
    norm_V = norm(V(i, :));
    V_norm = V(i, :) / norm_V;  % Vettore normalizzato
    angles(i) = acosd((P(i,3) - Q(3)) / norm_V);  % Angolo in gradi rispetto alla verticale
end

% Visualizza i vettori normalizzati e gli angoli
disp('Vettori direzionali normalizzati:');
disp(V_norm);
disp('Angoli rispetto alla verticale (in gradi):');
disp(angles);


