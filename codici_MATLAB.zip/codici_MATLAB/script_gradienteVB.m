clear all
close all
clc
%carico la mesh in questo caso utilizzo quella di un paziente in trattamento con vacuum bell
%inDir = '/Users/mariaelenalai/Downloads';
inDir ='/Users/mariaelenalai/Downloads/NUOVE_ACQUISIZIONI/';
%inDir ='/Users/mariaelenalai/Desktop/CARTELLA_PY/';
pectusMESH='Paz26_mesh.obj';
%pectusMESH='Paz2_preoperazione_mesh.obj';
[s]=loadawobj(fullfile(inDir,pectusMESH)); 
v=s.v;
F3=s.f3;

% Visualiazzo la mesh 
facecolor = v(3,:)';   
patch('Vertices',v','Faces',F3','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
view([0 0]);
axis('equal');
snapnow
pause(1)

% Trovo il piano che fitta la mesh
[n_1,V,p_1] = affine_fit(v') ;  % dove n_1 è la normale al piano e p_1 è un punto appartenente al piano
% crea una griglia di punti X e Y che definiscono una superficie 
[X,Y]=meshgrid(linspace(min(v(1,:)),max(v(1,:)),100),linspace(min(v(2,:)),max(v(2,:)),100)); 
hold on     % mantiene la figura corrente aperta in modo che il piano possa essere sovrapposto alla mesh
% plotta una superficie che rappresenta il piano trovato
surf(X,Y, - (n_1(1)/n_1(3)*X+n_1(2)/n_1(3)*Y-dot(n_1,p_1)/n_1(3)),'facecolor','red','facealpha',0.5); 

% Ruoto i vertici della mesh in modo tale che il piano trovato precedentemente sia parallelo al piano XY
% matrice di rotazione che ruota il vettore n_1 sull'asse Z in modo che diventi parallelo al vettore [0 0 1]
R1 = rotationVect3D(n_1,[0 0 1], eye(3)); 
v = v-p_1'; % centro la mesh sul piano XY
v = R1*v;   % ruoto i vertici
facecolor = v(3,:)';

figure
patch('Vertices',v','Faces',F3','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
view([0 0]);
axis('equal');
snapnow
pause(1)
%% Converto la mesh in una mesh regolare (quadrati), necessario per calcolare il gradiente

F =scatteredInterpolant(v(1,:)',v(2,:)',v(3,:)');
[X,Y]=meshgrid(linspace(min(v(1,:)),max(v(1,:)),100),linspace(min(v(2,:)),max(v(2,:)),100));

figure 
Z=F(X,Y);
[fx,fy]=gradient(Z); %calcolo il gradiente 
fig=figure(3);
surf(X,Y,Z,sqrt(fx.^2+fy.^2),'EdgeAlpha',0.7,'FaceAlpha',0.9,'EdgeColor','none') % il modulo del gradiente viene utilizzato per colorare i vertici
view([0 90]);
axis('equal');

%% Mesh della deformazione e mesh tagliata per trovare punto di minimo

[x,y,z]=ginput      % il comando ginput funziona in 2D. Permette di selezionare tre punti: il minimo e due punti a lato 

z(1)=(z(2)+z(3))/2;  % imposta l'altezza del punto minimo come la media delle altezze degli altri due punti
center = [x(1);y(1)]; % viene calcolato il centro
side = max(x)-min(x); % e la lunghezza del lato della mesh 2D

% Crea mesh sulla deformazione
[Xs,Ys]=meshgrid(center(1)+linspace(-side/2,side/2,100),center(2)+linspace(-side/2,side/2,100)); %crea mesh "tagliata" che racchiude la deformazione
Zs=F(Xs,Ys);

% Crea mesh più piccola per trovare il punto di minimo
[Xm,Ym]=meshgrid(center(1)+linspace(-2,2,100),center(2)+linspace(-2,2,100));    %crea mesh più piccola utile per trovare minimo
Zm=F(Xm,Ym);

[min_val,pos_idx]=min(Zm(:)); % cerca il minimo di Zm nella mesh 

% cerca i valori corrispondenti di Xm, Ym e Zm
Xmins = Xm(pos_idx);
Ymins = Ym(pos_idx);
Zmins = min_val;
%% Trovo la superficie tangente alla mesh 3D nel punto di minimo 

% Si calcolano le derivate parziali di F(X,Y) rispetto a X e Y utilizzando la funzione gradient
[fx,fy]=gradient(Zm); 

% Si cerca l'indice del punto corrispondente all'altezza minima
t = (Xm == Xmins) & (Ym == Ymins);
indt = find(t);

% Si calcolano le derivate di F nel punto di minima altezza
fx0 = fx(indt);
fy0 = fy(indt);

% Si calcola il vettore normale al piano tangente alla superficie 3D nel punto di minima altezza
normal_plane = [fx0 fy0 1];
normal_plane = normal_plane/norm(normal_plane);

% Si esegue una rotazione delle coordinate dei punti della superficie in modo da allineare il piano tangente con il piano xy
R2 = rotationVect3D(normal_plane,[0 0 1], eye(3));
v = (R2*[Xs(:)-Xmins Ys(:)-Ymins Zs(:)-Zmins]');

% Si ricostruiscono le facce della mesh a partire dalle coordinate ruotate
F3 = delaunay(Xs,Ys);

% si calcola il gradiente sulla griglia regolare originale Zs per colorare la mesh in base al gradiente
[fx,fy]=gradient(Zs);
facecolor = sqrt(fx.^2+fy.^2);

%% plot mesh con visualizzazione del gradiente 

figure; 
% figure1 = figure;
% axes1 = axes('Parent',figure1);
% hold(axes1,'on');
h=patch('Vertices',v','Faces',F3,'Facecolor','flat','CData',facecolor(:),'FaceVertexCData',facecolor(:),'edgecolor','none');
view([0 90]);

snapnow % serve a salvare l'immagine corrente e rendere immediatamente disponibile il file immagine salvato.
pause (1)

%% Contour al variare del valore del gradiente

hold off

value = 0; % Valore iniziale
figure1 = figure;

while true
    hold on
    
    surf(Xs-Xmins, Ys-Ymins, facecolor, 'EdgeColor', 'none');   % disegna una superficie 2D che rappresenta il gradiente
    hold on;
    view([0 90]);
   
    [x, y, button] = ginput(1);
    if button == 30 % Freccia su
        value = value + 0.1;
 
    end
    %value = min(max(value, 0), 1); % Limiti dell'intervallo [0, 1] 
    contour3(Xs-Xmins, Ys-Ymins, facecolor, [value value], 'k'); % Modifica il valore nel contour3  
    % visualizza una curva di livello alla volta: contour3(Xs, Ys, facecolor, [value value], 'k');
    if button == 28 % Freccia sinistra della tastiera
        break; % Esci dal ciclo
    end
end


%% Select points and draw a spline

hold on     % permette di sovrapporre i plot successivi sulla figura esistente

[x_s,y_s,z_s]=ginput;   % l'utente può selezionare i punti sulla figura poi cliccare invio quando ha finito
points=[x_s y_s z_s]';    % contiene le coordinate dei punti scelti dall'utente 
                            % e trasla di 4 la coordinata z così si
                            % visualizza meglio, senza essere tagliata dal contour

plot3(points(1,:),points(2,:),points(3,:),'r*','LineWidth',1);

figure
hold on
spline_1= cscvn(points(:,[1:end 1])); % crea una spline cubica su i punti selezionati dall'utente

fnplt(spline_1,'r');  % Visualizza la spline sul plot
[punti]=fnplt(spline_1,'r');  % calcola i punti della spline, quindi non quelli selezionati dall'utente ma tutti

% punti(:,size(punti(1,:)))=[];   % rimuove l'ultimo punto perché è lo stesso del primo punto, che è già stato incluso nella matrice.
%% Definisco la seconda spline (esterna) con un offset di 0.5

cx=punti(1,:); %coordinate x della spline 2D (interna)
cy=punti(2,:); %coordinate y della spline 2D (interna)

x_centroide = mean(cx); %coordinata x del centroide
y_centroide = mean(cy); %coordinata y del centroide

distanza = sqrt((cx - x_centroide).^2 + (cy - y_centroide).^2);  % calcolo della distanza euclidea di ogni punto rispetto al centroide
r = distanza+0.5; %viene aggiunto un offset di 0.5 alla distanza di ogni punto

% vengono calcolate le nuove coordinate dei punti traslati
theta = atan2(cy-y_centroide, cx-x_centroide);
new_x = r .* cos(theta) + x_centroide;
new_y = r .* sin(theta) + y_centroide;

%aggiungo il primo punto della spline alla fine degli array, in modo da creare un loop chiuso
new_x = [new_x(:); new_x(1)];
new_y = [new_y(:); new_y(1)];

%elimino i duplicati delle coordinate x e mantengo solo le coordinate y corrispondenti
[x_unique, idx] = unique(new_x);
y_unique = new_y(idx);

%costruisco la nuova spline e la visualizzo
new_spline = spline(x_unique, y_unique);

hold on
plot(new_x, new_y, 'b', 'LineWidth', 1);
%% Determino la coordinata z delle due spline
% 'natual': la funzione interpolante deve essere continua e avere derivate continue fino al secondo ordine
T = scatteredInterpolant(v(1,:)',v(2,:)',v(3,:)','natural'); 

%calcolo le coordinate di z
cz = T(cx, cy); 
cz_new=T(new_x, new_y);