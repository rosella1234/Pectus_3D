function vertices_transformed = applyTransform(M, vertices)
    % Applica una trasformazione affine ai vertici di una mesh 3D.
    % 
    % Input:
    % M - Matrice di rototraslazione 4x4
    % vertices - Matrice N x 3 dei vertici originali della mesh
    %
    % Output:
    % vertices_transformed - Matrice N x 3 dei vertici trasformati

    % Converte i vertici in coordinate omogenee aggiungendo una colonna di uni
    vertices_homogeneous = [vertices, ones(size(vertices, 1), 1)];
    
    % Applica la trasformazione affine
    vertices_transformed_homogeneous = (M * vertices_homogeneous')';
    
    % Converte i vertici trasformati di nuovo in coordinate cartesiane
    vertices_transformed = vertices_transformed_homogeneous(:, 1:3);
end
