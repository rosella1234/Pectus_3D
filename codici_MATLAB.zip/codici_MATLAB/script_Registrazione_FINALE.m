% Script registrazione

clear all 
close all
clc
% inDir = '/Users/mariaelenalai/Desktop/Tesi/Phantom04';
% inDir = '/Users/mariaelenalai/Desktop/Tesi/Paziente02';
inDir='/Users/mariaelenalai/Desktop/CARTELLA_PY/';
% inDir = '/Users/mariaelenalai/Downloads/Seconda_operata';

% sanoPC='ptCloud_postBLENDER.ply'; %seconda ragazza operata
% pectusPC='ptCloud_preBLENDER.ply';
% sanoPC='paz02post.ply'; %primo ragazzo operato
% pectusPC='paz02_pre.ply';
% % 
% % sanoMESH='Paz02PostMeshMesh.obj'; %primo ragazzo operato (10^6 poligoni)
% sanoMESH='Paz2_post_meshREVOSCANblender.obj';

% sanoMESH='Paz2_post_SEMPLIFICATA.obj'; % primo ragazzo mesh semplificatw
% pectusMESH='PAZ02_PREsemplificata.obj';

% sanoMESH='provaPOSTgrande.obj'; % primo ragazzo mesh semplificatw
%pectusMESH='Paz02PreMeshMesh.obj';
pectusMESH='Paz2_preoperazione_mesh.obj';
sanoMESH='Paz2_post_mesh.obj';
% sanoMESH='POST_def.obj'; %seconda ragazza operata

% pectusMESH='RagazzaPRE.obj';

% sanoMESH='Phantom4_MESHblender.obj'; %manichino
% sanoPC='Phantom4_PCblender.ply';
% 
% pectusMESH='Phantom4_excavMESH_blender.obj'; %manichino 
% pectusPC='Phantom4_excav_PCblender.ply';

% sanoMESH_pl='Phantom4_MESHblender.ply'; %manichino
% sanoPC_ob='Phantom4_PCblender.obj'; 


[s]=loadawobj(fullfile(inDir,sanoMESH)); 
v_sano = s.v;    %vertici
F3_sano = s.f3;  %facce

[p]=loadawobj(fullfile(inDir,pectusMESH)); 
v_pectus=p.v;
F3_pectus=p.f3;
%% REGISTRAZIONE TRAMITE ITERATIVE CLOSEST POINT (built-in)

% %carico point cloud
ptCloud_sano = pcread(fullfile(inDir,sanoPC));
ptCloud_pectus=pcread(fullfile(inDir,pectusPC));

%visualizzazione
figure
subplot(1,2,1)
pcshow(ptCloud_sano) 
subplot(1,2,2)
pcshow(ptCloud_pectus) 

mat=ptCloud_sano.Location;
mat_exc=ptCloud_pectus.Location;

% Registrazione dei point clouds
%ICP

[tform, sanoRegistered,rmse] = pcregistericp(ptCloud_sano, ptCloud_pectus);
disp(['Root Mean Square Error (RMSE): ', num2str(rmse)]); %per visualizzare valore

% Applicare la trasformazione al point cloud di origine
ptCloudAligned = pctransform(ptCloud_sano, tform);  %point cloud trasformato

% Visualizzare i point clouds per confrontare dopo la registrazione
figure;
pcshowpair(ptCloudAligned, ptCloud_pectus);
title('Point Cloud Registration Result'); % ptCloud_pectus è il point cloud di destinazione

legend('ptCloudAligned', 'ptCloud_pectus');
xlabel('X');
ylabel('Y');
zlabel('Z');

%% REGISTRAZIONE BASATA SU MARKER ANATOMICI SCELTI SU MESH GINPUT
%problema che non non ho coordinata z cioe solo 2D quindi i punti sono
%lontani non sulla mesh 
figure
%subplot(1,2,1)
facecolor = v_sano(3,:)'; % color patch according to vertices

patch('Vertices',v_sano','Faces',F3_sano','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
camlight('headlight'); % Aggiunge una luce nella posizione della camera
lighting gouraud; % Utilizza l'illuminazione Gouraud per un effetto morbido
material dull; % Rende il materiale meno riflettente per una visualizzazione più realistica

view([0 90]); %XY
axis('equal');
snapnow
pause(1)
[x1,y1]=ginput(3);
z1 = zeros(size(x1)); % Preallocate z-coordinates
for i = 1:length(x1)
    distances = sqrt((v_sano(1,1) - x1(i)).^2 + (v_sano(2,:) - y1(i)).^2);
    [~, idx] = min(distances);
    z1(i) = v_sano(3,idx);
end

% z1=mean(v_sano(3,:));
%primo punto capezzolo sx, secondo dx, terzo ombelico
hold on; % Mantiene il plot corrente

scatter3(x1, y1,z1, 'filled', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r');
xlabel('X');
ylabel('Y'); 
zlabel('Z');
hold off; % Rilascia il plot
%subplot(1,2,2)
figure
facecolor = v_pectus(3,:)';    % color patch according to vertices

patch('Vertices',v_pectus','Faces',F3_pectus','Facecolor','flat','CData',facecolor,'FaceVertexCData',facecolor,'FaceAlpha', .5,'edgecolor','none');
camlight('headlight'); % Aggiunge una luce nella posizione della camera
lighting gouraud; % Utilizza l'illuminazione Gouraud per un effetto morbido
material dull; % Rende il materiale meno riflettente per una visualizzazione più realistica

view([0 90]);
axis('equal');
snapnow
pause(1)
% [x2,y2,z2] = ginput3d(3)
[x2,y2]=ginput(3); %primo punto capezzolo sx, secondo dx, terzo ombelico
z2 = zeros(size(x2)); % Preallocate z-coordinates
for i = 1:length(x2)
    distances = sqrt((v_pectus(1,:) - x2(i)).^2 + (v_pectus(2,:) - y2(i)).^2);
    [~, idx] = min(distances);
    z2(i) = v_pectus(3,idx);
end

% z2=mean(v_pectus(3,:));
hold on; % Mantiene il plot corrente
scatter3(x2, y2,z2, 'filled', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r');
hold off; % Rilascia il plot

%% REGISTRAZIONE E VISUALIZZAZIONE MESH SOVRAPPOSTE
%La matrice di rotazione e la traslazione ottenuta vanno applicate anche
%alla nuvola di punti per vedere i diversi risultati 
Points_sano=[x1,y1,z1];
Points_pectus=[x2,y2,z2];

[R,t]=Registration_3D(Points_sano,Points_pectus);
v_registered = R * v_sano + t';
%% 

% Points_registered=(R*Points_sano'+t')';
transformed_source_pts = (R * Points_sano' + t')';

% Assuming transformed_source_pts and destination_pts are already defined
[rmse_REGfunz]=RMSEcalculation(transformed_source_pts,Points_pectus);

[TR_paper, TT_paper ] = icp(v_pectus,v_registered);
v_REGpaper=TR_paper*v_registered+TT_paper;

%Come paper Gomez et Al. 



%% Prova per trovare intersezione tra le 2 mesh MA DATI TROPPO GRANDI PER LA FUNZIONE BUILT-IN

% REGISTERED=struct('faces',F3_sano','vertices',v_REGpaper');
% PECTUS=struct('faces',F3_pectus','vertices',v_pectus');
% 
% [intMatrix, intSurface] = SurfaceIntersection(REGISTERED, PECTUS);


FV_reg = struct('faces',F3_sano','vertices',v_REGpaper'); %crea una struttura che contiene le informazioni sulla geometria della mesh
obj_write(FV_reg, 'manichino_post') 
FV_pect = struct('faces',F3_pectus','vertices',v_pectus'); 
obj_write(FV_pect, 'manichino_pect') 


FV_sano = struct('faces',F3_sano','vertices',v_sano');
obj_write(FV_sano, 'Paz02_pre') 

save("FileRagazzo.mat","FV_reg","FV_pect")
save("pqfile.mat","p","q")

FV_REGpy=struct('faces',F3_sano','vertices',v_REGpaper'); 
% obj_write(FV_reg, 'prova_py') 
FV_pectpy = struct('faces',F3_pectus','vertices',v_pectus'); 
%obj_write(FV_pect, 'manichino_pect')
%da salvare per esportare e non runnare tutto


%% PROVA VISUALIZZAZIONE TUTTE LE REGISTRAZIONI PROVATE
% v_REGpaper=FV_reg.vertices;
%X VISUALIZZARE PIU CHIARI 
figure
patch('Vertices', v_pectus', 'Faces', F3_pectus', 'FaceColor', [1 0 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
% hold on
% patch('Vertices', v_registered', 'Faces', F3_sano', 'FaceColor', [0 1 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
hold on
patch('Vertices', v_REGpaper', 'Faces', F3_sano', 'FaceColor', [0 1 1], 'FaceAlpha', 0.5, 'EdgeColor', 'none');


% hold on
% scatter3(v_pectus(1,indice_minimo_originale),v_pectus(2,indice_minimo_originale),v_pectus(3,indice_minimo_originale),'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k')

% patch('Vertices', v_registered', 'Faces', F3_sano', 'FaceColor', [0 1 0], 'FaceAlpha', 0.5, 'EdgeColor', 'none');
view([0 0])
xlabel('X');
ylabel('Y');
zlabel('Z');
sgtitle('V_pectus VS V_registered (my funz)')