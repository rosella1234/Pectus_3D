function [rmse]=RMSEcalculation(transformed_source_pts,destination_pts)

% Calculate differences between each corresponding point
differences = transformed_source_pts - destination_pts;
% Square the differences, sum them up, and then take the mean
mean_squared_error = mean(sum(differences.^2, 2));
% Take the square root to obtain RMSE
rmse = sqrt(mean_squared_error);
fprintf('The RMSE between the e points is: %f\n', rmse); %quindi in teoria è piu basso dell icp 

end