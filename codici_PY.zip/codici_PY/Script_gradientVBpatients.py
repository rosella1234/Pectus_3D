import numpy as np
import open3d as o3d
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from scipy.interpolate import griddata
from scipy.linalg import svd


def fit_plane(points):
    """
    Fit a plane to a set of points using least squares.
    
    Args:
    points: A Nx3 matrix where each row is a sample point
    
    Returns:
    n: the vector normal to the plane
    V: A 3x2 matrix. The columns of V form an orthonormal basis of the plane
    p: A point belonging to the plane
    """
    try:
        # Compute the centroid of the points
        p = np.mean(points, axis=0)
        
        # Subtract the centroid from the points
        centered_points = points - p
        
        # Compute the Singular Value Decomposition
        U, S, Vt = svd(centered_points, full_matrices=False)
        
        # The normal to the plane is given by the last column of Vt
        n = Vt[-1]
        
        # The first two columns of Vt.T that form an orthonormal basis for the plane
        V = Vt[:2].T
        
        return n, V, p
    
    except MemoryError:
        print("MemoryError: The input data is too large to fit in memory.")
        return None, None, None
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None, None

def rotationVect3D(vec1, vec2):
    """
    Compute the rotation matrix that rotates vec1 to be parallel to vec2.
    
    Args:
    vec1: The source vector.
    vec2: The target vector.
    
    Returns:
    The rotation matrix that aligns vec1 with vec2.
    """
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    
    vec1 = vec1 / np.linalg.norm(vec1)
    vec2 = vec2 / np.linalg.norm(vec2)
    
    # Compute the cross product and the dot product to find the axis of rotation and the angle (cos) between the vectors
    cross_prod = np.cross(vec1, vec2)
    dot_prod = np.dot(vec1, vec2)
    
    # If the vectors are parallel returns the identity matrix, representing no rotation
    if np.isclose(dot_prod, 1.0):
        return np.eye(3)
    
    # Create the skew-symmetric cross-product matrix (K)
    
    cross_prod_matrix = np.array([[0, -cross_prod[2], cross_prod[1]],
                                  [cross_prod[2], 0, -cross_prod[0]],
                                  [-cross_prod[1], cross_prod[0], 0]])
    
    # Compute the rotation matrix using the Rodrigues' rotation formula: R=I+sin(theta)*K+(1-cos(theta)*K^2)
    identity_matrix = np.eye(3)
    rotation_matrix = (identity_matrix + cross_prod_matrix + 
                       (cross_prod_matrix @ cross_prod_matrix) * ((1 - dot_prod) / (np.linalg.norm(cross_prod) ** 2)))
    
    return rotation_matrix

def rotate_and_visualize_mesh(v, n_1, p_1,R1):
    # Ensure the normal vector points in the positive Z direction
    if n_1[2] < 0:
        n_1 = -np.array(n_1)

    
    v_centered = v - p_1
    
    v_rotated = (R1 @ v_centered.T).T
    
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(v_rotated)

    # Visualization of the point cloud
    o3d.visualization.draw_geometries([pcd])
    
    return v_rotated,pcd

def pick_points(pcd):
    print("")
    print(
        "1) Please pick at least three correspondences using [shift + left click]"
    )
    print("   Press [shift + right click] to undo point picking")
    print("2) Afther picking points, press q for close the window")
    vis = o3d.visualization.VisualizerWithEditing()
    vis.create_window()
    vis.add_geometry(pcd)
    vis.run()  # user picks points
    vis.destroy_window()
    print("")
    return vis.get_picked_points()

base_path='/Users/mariaelenalai/Downloads/NUOVE_ACQUISIZIONI/Paz26_mesh.ply'
#base_path='/Users/mariaelenalai/Desktop/CARTELLA_PY/Paz2_preoperazione_mesh.ply'
#base_path='/Users/mariaelenalai/Downloads/acquisizioni_excavatum/day8/Paz55/Paz55_mesh.ply'

pcd_orig= o3d.io.read_point_cloud(base_path)

points =np.asarray(pcd_orig.points)
#print(points.shape)  # to check dimensions

n_1, V, p_1 = fit_plane(points)

R1 = rotationVect3D(n_1, [0, 0, 1])

V_ROT,pcd_rot=rotate_and_visualize_mesh(points,n_1,p_1,R1)


indices_parametro= pick_points(pcd_rot) 
picked_points = np.asarray(pcd_rot.points)[indices_parametro] 
nipple_left = picked_points[0]
nipple_right = picked_points[1]
cost_left = picked_points[2]
cost_right=picked_points[3]

roi = (
    (V_ROT[:, 0] >= nipple_left[0]) & 
    (V_ROT[:, 0] <= nipple_right[0]) & 
    (V_ROT[:, 1] <= nipple_left[1]) & 
    (V_ROT[:, 1] <= nipple_right[1]) & 
    (V_ROT[:, 1] >= cost_left[1]) & 
    (V_ROT[:, 1] >= cost_right[1])
)

# Points in the ROI (rotated to be parallel to xy-plane)
roi_points = V_ROT[roi]

# Find the value of minimum point in the ROI from its index and corresponding index on the original mesh
min_point_indexROI = np.argmin(roi_points[:, 2])
original_indices = np.where(roi)[0]

min_point_index_original = original_indices[min_point_indexROI]
min_point=points[min_point_index_original,:]

print(min_point)
min_pointROI=roi_points[min_point_indexROI,:]
print(min_pointROI)

min_x=min_pointROI[0]
min_y=min_pointROI[1]
min_z=min_pointROI[2]



# Sphere design to visualize the minimum point on the mesh
sphere = o3d.geometry.TriangleMesh.create_sphere(radius=5)
sphere.translate(min_point)
sphere.paint_uniform_color([1, 0, 0]) 

o3d.visualization.draw_geometries([pcd_orig,sphere])

sphereROI = o3d.geometry.TriangleMesh.create_sphere(radius=5)
sphereROI.translate(min_pointROI)
sphereROI.paint_uniform_color([1, 0, 0]) 

pcd_roi= o3d.geometry.PointCloud()
pcd_roi.points = o3d.utility.Vector3dVector(roi_points)

o3d.visualization.draw_geometries([pcd_roi,sphereROI]) # visualization only roi

x = roi_points[:, 0]
y = roi_points[:, 1]
z = roi_points[:, 2]

# Creation of the grid 
xi = np.linspace(x.min(), x.max(), 100)
yi = np.linspace(y.min(), y.max(), 100)

# Trova gli indici i, j nella griglia più vicini a min_point_x e min_point_y
i = np.abs(xi - min_x).argmin()#AGG
j = np.abs(yi - min_y).argmin()#AGG

print(i,j)
xi_grid, yi_grid = np.meshgrid(xi, yi)

# Data interpolation on the grid created 
zi = griddata((x, y), z, (xi_grid, yi_grid), method='cubic')

fx, fy = np.gradient(zi)
gradient_magnitude = np.sqrt(fx**2 + fy**2)
# gradient in the min point
fx0=fx[i,j] 
fy0=fy[i,j] 
# normal of the tangent plane passing through the min poin
normal_plane = np.array([fx0, fy0, 1])
normal_plane = normal_plane / np.linalg.norm(normal_plane)

print("Vettore normale al piano tangente:", normal_plane)


# Contourn lines (2D) plot
plt.contour(xi, yi, gradient_magnitude, levels=14, linewidths=0.5, colors='k')
plt.contourf(xi, yi, gradient_magnitude, levels=14, cmap="RdBu_r")
plt.colorbar()
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Contourn Lines')
plt.show()


# Creation 3D surface with Plotly (colored by gradient magnitude)
fig = go.Figure()

fig = go.Figure(data=[
    go.Surface(z=zi, x=xi_grid, y=yi_grid, surfacecolor=gradient_magnitude, 
               colorscale='Viridis', opacity=0.9)
])

fig.update_layout(title='Surface Colored by Gradient Magnitude', autosize=False,
                  scene_camera_eye=dict(x=1.87, y=0.88, z=-0.64),
                  width=700, height=700,
                  margin=dict(l=65, r=50, b=65, t=90))
fig.show()

fig = go.Figure()
fig.add_trace(go.Surface(z=gradient_magnitude, x=xi_grid, y=yi_grid, colorscale='Viridis', opacity=0.9))

#  To add interative contour lines on the same plot
fig.add_trace(go.Surface(z=gradient_magnitude, x=xi_grid, y=yi_grid, surfacecolor=gradient_magnitude,
                         colorscale='Jet', showscale=False, opacity=0.5, contours=dict(
                             z=dict(show=True, usecolormap=True, highlightcolor="limegreen", project_z=True)
                         )))

fig.update_layout(title='ROI Points Gradients Magnitude with Gradient Contours', autosize=False,
                  scene_camera_eye=dict(x=0, y=0, z=2),
                  width=700, height=700,
                  margin=dict(l=65, r=50, b=65, t=90))
fig.show()

