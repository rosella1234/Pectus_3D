import numpy as np
import open3d as o3d
import matplotlib.pyplot as plt
from scipy.linalg import svd

def pick_points(pcd):
    print("")
    print(
        "1) Please pick at least three correspondences using [shift + left click]"
    )
    print("   Press [shift + right click] to undo point picking")
    print("2) Afther picking points, press q for close the window")
    vis = o3d.visualization.VisualizerWithEditing()
    vis.create_window()
    vis.add_geometry(pcd)
    vis.run()  # user picks points
    vis.destroy_window()
    print("")
    return vis.get_picked_points()

def fit_plane(points):
    """
    Fit a plane to a set of points using least squares.
    Args:
    points: A Nx3 matrix where each row is a sample point
    Returns:
    n: A unit (column) vector normal to the plane
    V: A 3x2 matrix. The columns of V form an orthonormal basis of the plane
    p: A point belonging to the plane
    """
    try:
        # Compute the centroid of the points
        p = np.mean(points, axis=0)
        # Subtract the centroid from the points
        centered_points = points - p
        # Compute the Singular Value Decomposition
        U, S, Vt = svd(centered_points, full_matrices=False)
        # The normal to the plane is given by the last column of Vt
        n = Vt[-1]
        # The first two columns of Vt.T form an orthonormal basis for the plane
        V = Vt[:2].T
        return n, V, p
    
    except MemoryError:
        print("MemoryError: The input data is too large to fit in memory.")
        return None, None, None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None, None

def rotationVect3D(vec1, vec2):
    """
    Compute the rotation matrix that rotates vec1 to be parallel to vec2.
    
    Args:
    vec1: The source vector.
    vec2: The target vector.
    
    Returns:
    The rotation matrix that aligns vec1 with vec2.
    """
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    
    vec1 = vec1 / np.linalg.norm(vec1)
    vec2 = vec2 / np.linalg.norm(vec2)
    
    # Compute the cross product and the dot product to find the axis of rotation and the angle (cos) between the vectors
    cross_prod = np.cross(vec1, vec2)
    dot_prod = np.dot(vec1, vec2)
    
    # If the vectors are parallel returns the identity matrix, representing no rotation
    if np.isclose(dot_prod, 1.0):
        return np.eye(3)
    
    # Create the skew-symmetric cross-product matrix (K)
    cross_prod_matrix = np.array([[0, -cross_prod[2], cross_prod[1]],
                                  [cross_prod[2], 0, -cross_prod[0]],
                                  [-cross_prod[1], cross_prod[0], 0]])
    
    # Compute the rotation matrix using the Rodrigues' rotation formula: R=I+sin(theta)*K+(1-cos(theta)*K^2)
    identity_matrix = np.eye(3)
    rotation_matrix = (identity_matrix + cross_prod_matrix + 
                       (cross_prod_matrix @ cross_prod_matrix) * ((1 - dot_prod) / (np.linalg.norm(cross_prod) ** 2)))
    
    return rotation_matrix

def rotate_and_visualize_mesh(v, n_1, p_1):
    # Ensure the normal vector points in the positive Z direction
    if n_1[2] < 0:
        n_1 = -np.array(n_1)
    # Compute the rotation matrix
    R1 = rotationVect3D(n_1, [0, 0, 1])
    # Center the mesh on the plane XY and apply rotation
    v_centered = v - p_1
    v_rotated = (R1 @ v_centered.T).T
    # Create an open3d point cloud for visualization
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(v_rotated)
    o3d.visualization.draw_geometries([pcd])
    return v_rotated,pcd

def create_plane_mesh_from_points(points, size_factor=1.0):
    """
    Create a plane mesh that passes through given points using the SVD method.
    Parameters:
    points: Array of points with shape (N, 3)
    size_factor: Factor to scale the size of the plane
    """
    # Mean calculation
    media_punti = np.mean(points, axis=0)

    punti_cent = points - media_punti

    # Singular Value Decomposition (SVD)
    U, S, Vt = np.linalg.svd(punti_cent, full_matrices=False)
    V = Vt.T

    normale = V[:, -1] # Il vettore normale al piano è l'ultima colonna di V
    
    d = np.dot(normale, media_punti) # d è il prodotto scalare della normale e uno dei punti mediati
   
    # Create a grid of points in the plane 
    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    z_min, z_max = np.min(points[:, 2]), np.max(points[:, 2])
    
    # Scale the size of the plane
    x_range = (x_max - x_min) * size_factor
    y_range = (y_max - y_min) * size_factor
    
    x = np.linspace(x_min - x_range, x_max + x_range, 10)
    y = np.linspace(y_min - y_range, y_max + y_range, 10)
    X, Y = np.meshgrid(x, y)

    # Calculate corresponding z values
    Z = (d - normale[0] * X - normale[1] * Y) / normale[2]

    # Create the mesh grid points
    points = np.vstack((X.flatten(), Y.flatten(), Z.flatten())).T
    mesh = o3d.geometry.TriangleMesh()
    mesh.vertices = o3d.utility.Vector3dVector(points)
    # Create triangles for the mesh
    triangles = []
    for i in range(9):
        for j in range(9):
            triangles.append([i * 10 + j, i * 10 + j + 1, (i + 1) * 10 + j])
            triangles.append([(i + 1) * 10 + j, i * 10 + j + 1, (i + 1) * 10 + j + 1])
    mesh.triangles = o3d.utility.Vector3iVector(triangles)
    mesh.compute_vertex_normals()
    return mesh, normale, d

def steepness_calculation(point, min_point,dist_min):
    """ 
    Steepness calculation between points on the plane and min poin, respect to the plane
    Args:
    point: 3D coordinates of the selected point
    min_point: 3D coordinates of the min point
    dist_min: distance between the min and the plane
    
    Returns:
    theta_paper= steepness (90-theta)
    """
    # Vector between the two points 
    vettore_PM = np.array(min_point) - np.array(point)
    norma_PM = np.linalg.norm(vettore_PM) #ipotenusa
    theta_gradi=np.degrees(np.arccos(dist_min/norma_PM))
    theta_paper=90-theta_gradi
    
    return theta_paper


#base_path='/Users/mariaelenalai/Downloads/acquisizioni_excavatum/day4/Paz28/Paz28_mesh.ply'
base_path='/Users/mariaelenalai/Desktop/CARTELLA_PY/Paz2_preoperazione_mesh.ply'

pcd_orig= o3d.io.read_point_cloud(base_path)

gray_color = [0.5, 0.5, 0.5]  # RGB per il grigio
pcd_orig.colors = o3d.utility.Vector3dVector(np.tile(gray_color, (len(pcd_orig.points), 1)))
o3d.visualization.draw_geometries([pcd_orig])
points =np.asarray(pcd_orig.points)
#print(points.shape) #check 
n_1, V, p_1 = fit_plane(points)
#print("Normal vector to the plane:", n_1)
#print("Orthonormal basis of the plane:", V)
#print("Point belonging to the plane:", p_1)

V_ROT,pcd_rot=rotate_and_visualize_mesh(points,n_1,p_1)

indices_parametro= pick_points(pcd_rot) 
picked_points = np.asarray(pcd_rot.points)[indices_parametro] 
nipple_left = picked_points[0]
nipple_right = picked_points[1]
cost_left = picked_points[2]
cost_right=picked_points[3]

points_pectus = np.asarray(pcd_rot.points) 

#points_original=np.asarray(points)
#area in cui cercare il punto di minimo ROI
roi = (points_pectus[:,0] >= nipple_left[0]) & (points_pectus[:,0] <= nipple_right[0])  & (points_pectus[:,1] <= nipple_left[1])& (points_pectus[:,1] >= cost_right[1])
roi_points = points_pectus[roi,:]

# Find the point with the minimum z-value
min_point_indexROI = np.argmin(roi_points[:, 2])
original_indices = np.where(roi)[0]
min_point_index_original = original_indices[min_point_indexROI]
min_point=points[min_point_index_original,:]
sphere_min = o3d.geometry.TriangleMesh.create_sphere(radius=5)
sphere_min.translate(min_point)
sphere_min.paint_uniform_color([1, 0, 0]) 


pcd_orig.paint_uniform_color([0.5, 0.5, 0.5])
pcd_orig.colors = o3d.utility.Vector3dVector(np.tile(gray_color, (len(points), 1)))

o3d.visualization.draw_geometries([pcd_orig, sphere_min], zoom=0.8, front=[0, 0, -1], lookat=min_point, up=[0, -1, 0],window_name="Punto di minimo della deformazione")

#Selezione capezzoli e ombelico attraverso cui far passare il piano per calcolare profondità e pendenza:
indices_piano=pick_points(pcd_orig) 
picked_pointsPLANE = np.asarray(pcd_orig.points)[indices_piano] 
#print(picked_pointsPLANE)
plane_mesh,normale,d = create_plane_mesh_from_points(picked_pointsPLANE , size_factor=1)
print(f'Plane equation: {normale[0]:.2f}x + {normale[1]:.2f}y + {normale[2]:.2f}z = {d:.2f}')
# 3D visualization of mesh+ plane and point of maximum deformation to appreciate depth
o3d.visualization.draw_geometries([pcd_orig, plane_mesh,sphere_min],window_name="Mesh con PE, piano passante per i punti selezionati, punto di minimo")  
numerator= abs(normale[0] * min_point[0] + normale [1]* min_point[1] + normale[2] * min_point[2] -d)
denominator = np.sqrt(normale[0]**2 + normale[1]**2 + normale[2]**2)
depth = numerator / denominator
print(f'The depth of the depression is: {depth:.2f} mm')
#print(min_point)
# Calcolo delle pendenze per ciascuno dei tre punti rispetto al punto di minimo
steep_p1= steepness_calculation(picked_pointsPLANE[0], min_point,depth)
steep_p2 = steepness_calculation(picked_pointsPLANE[1], min_point,depth)
steep_p3 = steepness_calculation(picked_pointsPLANE[2], min_point,depth)
#x Paz72 (Marfan) anche punto 4:
#steep_p4= steepness_calculation(picked_pointsPLANE[3], min_point,depth)
print(f"Steepness left nipple-min_point: {steep_p1:.2f} degrees")
print(f"Steepness right nipple-min_point: {steep_p2:.2f} degrees")
print(f"Steepness navel-min_point: {steep_p3:.2f} degrees")

## STEEPNESS VISUALIZATION 

# Creation of spheres (for all points selected and min)
spheres = []
for point in picked_pointsPLANE:
    sphere = o3d.geometry.TriangleMesh.create_sphere(radius=3)
    sphere.translate(point)
    sphere.paint_uniform_color([0, 1, 0])  # GREEN
    spheres.append(sphere)
spheres.append(sphere_min)
# Lines bewteen each point in picked_pointsORIGINALE and min_point
lines = np.array([[i, len(picked_pointsPLANE)] for i in range(len(picked_pointsPLANE))])
all_points = np.vstack([picked_pointsPLANE, min_point])

# Object LineSet to plot the linees (for steepness)
line_set = o3d.geometry.LineSet()
line_set.points = o3d.utility.Vector3dVector(all_points)
line_set.lines = o3d.utility.Vector2iVector(lines)
colors = [[1, 0, 0] for _ in range(len(lines))]  # RED for lines
line_set.colors = o3d.utility.Vector3dVector(colors)
all_geometries = [pcd_orig] + spheres + [line_set]
# Visualization all together
o3d.visualization.draw_geometries(all_geometries)

